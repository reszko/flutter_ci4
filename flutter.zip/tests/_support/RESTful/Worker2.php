<?php
namespace Tests\Support\RESTful;

use CodeIgniter\RESTful\ResourcePresenter;

/**
 * An extendable controller to provide a RESTful API for a resource.
 */
class Worker2 extends ResourcePresenter
{

}
