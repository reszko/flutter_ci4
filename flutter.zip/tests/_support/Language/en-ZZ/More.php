<?php
return [
   'strongForce' => 'These are not the droids you are looking for',
   'notaMoon'    => "It's made of cheese",
   'wisdom'      => 'There is no try',
];
