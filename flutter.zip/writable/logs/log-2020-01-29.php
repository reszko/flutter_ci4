<?php defined('SYSTEMPATH') || exit('No direct script access allowed'); ?>

CRITICAL - 2020-01-29 18:36:59 --> Undefined variable: route
#0 C:\xampp\htdocs\flutter\app\Config\Routes.php(76): CodeIgniter\Debug\Exceptions->errorHandler(8, 'Undefined varia...', 'C:\\xampp\\htdocs...', 76, Array)
#1 C:\xampp\htdocs\flutter\system\CodeIgniter.php(712): require('C:\\xampp\\htdocs...')
#2 C:\xampp\htdocs\flutter\system\CodeIgniter.php(298): CodeIgniter\CodeIgniter->tryToRouteIt(Object(CodeIgniter\Router\RouteCollection))
#3 C:\xampp\htdocs\flutter\system\CodeIgniter.php(246): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#4 C:\xampp\htdocs\flutter\system\CLI\Console.php(86): CodeIgniter\CodeIgniter->run()
#5 C:\xampp\htdocs\flutter\spark(57): CodeIgniter\CLI\Console->run()
#6 {main}
